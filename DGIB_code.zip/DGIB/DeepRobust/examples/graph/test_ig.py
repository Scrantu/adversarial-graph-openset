import torch
import numpy as np
import torch.nn.functional as F
import torch.optim as optim
from deeprobust.graph.defense import GCN
from deeprobust.graph.targeted_attack import IGAttack
from deeprobust.graph.utils import *
from deeprobust.graph.data import Dataset
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--seed", type=int, default=15, help="Random seed.")
parser.add_argument(
    "--dataset",
    type=str,
    default="citeseer",
    choices=["cora", "cora_ml", "citeseer", "polblogs", "pubmed"],
    help="dataset",
)
parser.add_argument("--ptb_rate", type=float, default=0.05, help="pertubation rate")

args = parser.parse_args()
args.cuda = torch.cuda.is_available()
print("cuda: %s" % args.cuda)
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

np.random.seed(args.seed)
torch.manual_seed(args.seed)
if args.cuda:
    torch.cuda.manual_seed(args.seed)

data = Dataset(root="/tmp/", name=args.dataset)
adj, features, labels = data.adj, data.features, data.labels
idx_train, idx_val, idx_test = data.idx_train, data.idx_val, data.idx_test

idx_unlabeled = np.union1d(idx_val, idx_test)

# Setup Surrogate model
surrogate = GCN(
    nfeat=features.shape[1],
    nclass=labels.max().item() + 1,
    nhid=16,
    dropout=0,
    with_relu=False,
    with_bias=False,
    device=device,
)

surrogate = surrogate.to(device)
surrogate.fit(features, adj, labels, idx_train)

# Setup Attack Model
target_node = 0
assert target_node in idx_unlabeled

model = IGAttack(
    surrogate,
    nnodes=adj.shape[0],
    attack_structure=True,
    attack_features=True,
    device=device,
)
model = model.to(device)


def main():
    degrees = adj.sum(0).A1
    # How many perturbations to perform. Default: Degree of the node
    n_perturbations = int(degrees[target_node])

    model.attack(
        features, adj, labels, idx_train, target_node, n_perturbations, steps=10
    )
    modified_adj = model.modified_adj
    modified_features = model.modified_features

    print("=== testing GCN on original(clean) graph ===")
    test(adj, features, target_node)

    print("=== testing GCN on perturbed graph ===")
    test(modified_adj, modified_features, target_node)


def test(adj, features, target_node):
    """ test on GCN """
    gcn = GCN(
        nfeat=features.shape[1],
        nhid=16,
        nclass=labels.max().item() + 1,
        dropout=0.5,
        device=device,
    )

    gcn = gcn.to(device)

    gcn.fit(features, adj, labels, idx_train)

    gcn.eval()
    output = gcn.predict()
    probs = torch.exp(output[[target_node]])[0]
    print("probs: {}".format(probs.detach().cpu().numpy()))
    acc_test = accuracy(output[idx_test], labels[idx_test])

    print("Test set results:", "accuracy= {:.4f}".format(acc_test.item()))

    return acc_test.item()


if __name__ == "__main__":
    main()
