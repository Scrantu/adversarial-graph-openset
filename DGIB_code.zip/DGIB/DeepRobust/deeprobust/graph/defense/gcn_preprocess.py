import torch.nn as nn
import torch.nn.functional as F
import math
import torch
from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module
import sys, os

sys.path.append(os.path.join(os.path.dirname("__file__"), "..", "..", ".."))
from DGIB.DeepRobust.deeprobust.graph import utils
from DGIB.DeepRobust.deeprobust.graph.defense import GCN
from tqdm import tqdm
import scipy.sparse as sp
import numpy as np


class GCNSVD(GCN):
    def __init__(
        self,
        nfeat,
        nhid,
        nclass,
        dropout=0.5,
        lr=0.01,
        weight_decay=5e-4,
        with_relu=True,
        with_bias=True,
        device="cpu",
    ):

        super(GCNSVD, self).__init__(
            nfeat,
            nhid,
            nclass,
            dropout,
            lr,
            weight_decay,
            with_relu,
            with_bias,
            device=device,
        )
        self.device = device

    def fit(
        self,
        features,
        adj,
        labels,
        idx_train,
        idx_val=None,
        k=50,
        train_iters=200,
        initialize=True,
        verbose=True,
    ):

        modified_adj = self.truncatedSVD(adj, k=k)
        # modified_adj_tensor = utils.sparse_mx_to_torch_sparse_tensor(self.modified_adj)
        features, modified_adj, labels = utils.to_tensor(
            features, modified_adj, labels, device=self.device
        )

        self.modified_adj = modified_adj
        self.features = features
        self.labels = labels
        super().fit(
            features,
            modified_adj,
            labels,
            idx_train,
            idx_val,
            train_iters=train_iters,
            initialize=initialize,
            verbose=verbose,
        )

    def truncatedSVD(self, data, k=50):
        # print('=== GCN-SVD: rank={} ==='.format(k))
        if sp.issparse(data):
            data = data.asfptype()
            U, S, V = sp.linalg.svds(data, k=k)
            # print("rank_after = {}".format(len(S.nonzero()[0])))
            diag_S = np.diag(S)
        else:
            U, S, V = np.linalg.svd(data)
            U = U[:, :k]
            S = S[:k]
            V = V[:k, :]
            # print("rank_before = {}".format(len(S.nonzero()[0])))
            diag_S = np.diag(S)
            # print("rank_after = {}".format(len(diag_S.nonzero()[0])))

        return U @ diag_S @ V


class GCNJaccard(GCN):
    def __init__(
        self,
        nfeat,
        nhid,
        nclass,
        binary_feature=True,
        dropout=0.5,
        lr=0.01,
        weight_decay=5e-4,
        with_relu=True,
        with_bias=True,
        num_layers=2,
        device="cpu",
    ):

        super(GCNJaccard, self).__init__(
            nfeat,
            nhid,
            nclass,
            dropout,
            lr,
            weight_decay,
            with_relu,
            with_bias,
            num_layers=num_layers,
            device=device,
        )
        self.device = device
        self.binary_feature = binary_feature

    def fit(
        self,
        features,
        adj,
        labels,
        idx_train,
        idx_val=None,
        threshold=0.01,
        train_iters=200,
        initialize=True,
        verbose=True,
    ):
        self.threshold = threshold
        modified_adj = self.drop_dissimilar_edges(features, adj)
        # modified_adj_tensor = utils.sparse_mx_to_torch_sparse_tensor(self.modified_adj)
        features, modified_adj, labels = utils.to_tensor(
            features, modified_adj, labels, device=self.device
        )
        self.modified_adj = modified_adj
        self.features = features
        self.labels = labels
        super().fit(
            features,
            modified_adj,
            labels,
            idx_train,
            idx_val,
            train_iters=train_iters,
            initialize=initialize,
            verbose=verbose,
        )

    def drop_dissimilar_edges(self, features, adj):
        if not sp.issparse(adj):
            adj = sp.csr_matrix(adj)
        modified_adj = adj.copy().tolil()
        # preprocessing based on features

        print("=== GCN-Jaccrad ===")
        # isSparse = sp.issparse(features)
        edges = np.array(modified_adj.nonzero()).T
        removed_cnt = 0
        for edge in tqdm(edges):
            n1 = edge[0]
            n2 = edge[1]
            if n1 > n2:
                continue

            # if isSparse:
            if self.binary_feature:
                J = self._jaccard_similarity(features[n1], features[n2])

                if J < self.threshold:
                    modified_adj[n1, n2] = 0
                    modified_adj[n2, n1] = 0
                    removed_cnt += 1
            else:
                # For not binary feature, use cosine similarity
                C = self._cosine_similarity(features[n1], features[n2])
                if C < self.threshold:
                    modified_adj[n1, n2] = 0
                    modified_adj[n2, n1] = 0
                    removed_cnt += 1
        print("removed %s edges in the original graph" % removed_cnt)
        return modified_adj

    def _jaccard_similarity(self, a, b):
        intersection = a.multiply(b).count_nonzero()
        J = intersection * 1.0 / (a.count_nonzero() + b.count_nonzero() - intersection)
        return J

    def _cosine_similarity(self, a, b):
        inner_product = (features[n1] * features[n2]).sum()
        C = inner_product / np.sqrt(np.square(a).sum() + np.square(b).sum())
        return C
