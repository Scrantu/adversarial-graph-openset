import torch
from torch import nn
from torch.nn import functional as F
from torch import optim
import numpy as np

import sys
from torch_geometric.data import Data
from torch_geometric.datasets import Planetoid
from torch_geometric.nn import GCNConv

class GCN_model2(nn.Module):
    def __init__(self, in_feat, h_feat, out_feat, num_layers):
        super().__init__()
        self.Conv1 = GCNConv(in_feat, h_feat)
        self.Conv2 = GCNConv(h_feat, out_feat)
        self.clf1 = nn.Linear(out_feat, num_layers)
    
    def forward(self, seq, edge_index):
        """标准的前向传播"""
        res1 = self.Conv1(seq, edge_index)
        out = F.relu(res1)
        out = F.dropout(out, p=0.5, training=self.training)

        res2 = self.Conv2(out, edge_index)
        res2 = F.relu(res2)
        res2 = F.dropout(res2, p=0.5, training=self.training)

        res3 = self.clf1(res2)
        return res3

    def forward_with_embeddings(self, embeddings, edge_index):
        """从中间层嵌入开始的前向传播"""
        res2 = self.Conv2(embeddings, edge_index)
        res2 = F.relu(res2)
        res2 = F.dropout(res2, p=0.5, training=self.training)
        
        res3 = self.clf1(res2)
        return res3
        
    def get_embeddings(self, seq, edge_index):
        """获取中间层嵌入"""
        with torch.no_grad():
            return self.Conv1(seq, edge_index)

