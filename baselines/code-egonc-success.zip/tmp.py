import torch
import torch.nn.functional as F
from torch_geometric.datasets import Planetoid
from torch_geometric.nn import GCNConv
from torch_geometric.data import Data
import numpy as np
from sklearn.model_selection import train_test_split
from torch.distributions.beta import Beta

# 配置参数
args = {
    'lr': 0.05,
    'alpha': 1.0,  # Beta分布参数
    'beta': 1.0,   # 外部替代节点系数
    'gamma': 1.0,  # 外部替代节点系数
    'lambda1': 1.0,
    'lambda2': 0.1,
    'lambda3': 0.01,
    'k1': 0.1,     # 能量正则化线性项权重
    'k2': 0.01,    # 能量正则化二次项权重
    't_in': -1.0,  # 已知类能量阈值
    't_out': 1.0,  # 未知类能量阈值
    'known_class': 6,  # Cora数据集有7类，未知类设为6（0-based索引）
    'epochs': 300
}

# 加载Cora数据集
dataset = Planetoid(root = "C:\\Users\\zhaoc\\Desktop\\DGIB\\data\\cora\\", name = 'cora')
data = dataset[0]
seed = 0

def make_openset_split_auto(data, known_class_ratio=0.7, train_ratio=0.1, val_ratio=0.1, seed=0, save_path=None):
    """将部分类别作为 unknown 类，划分 openset 节点分类任务"""
    from sklearn.model_selection import train_test_split
    import pickle

    labels = data.y.cpu().numpy()
    all_classes = np.unique(labels)
    num_classes = len(all_classes)

    # 确定已知类和未知类
    num_known = int(num_classes * known_class_ratio)
    shuffled_classes = np.random.permutation(all_classes)
    known_classes = shuffled_classes[:num_known]
    unknown_classes = shuffled_classes[num_known:]

    print(f"Known classes: {known_classes.tolist()}")
    print(f"Unknown classes: {unknown_classes.tolist()}")

    # 重映射标签
    label_map = {cls: i for i, cls in enumerate(known_classes)}
    unknown_class_id = num_known
    for cls in unknown_classes:
        label_map[cls] = unknown_class_id
    
    new_labels = np.array([label_map[y] for y in labels])
    data.y = torch.from_numpy(new_labels).to(torch.long)

    # 划分已知和未知样本
    known_mask = np.isin(new_labels, list(range(num_known)))
    unknown_mask = new_labels == unknown_class_id

    known_indices = np.where(known_mask)[0]
    unknown_indices = np.where(unknown_mask)[0]

    # 划分训练/验证/测试集
    train_idx, rest_idx = train_test_split(
        known_indices, train_size=train_ratio, random_state=seed, 
        stratify=new_labels[known_indices]
    )
    val_size = val_ratio / (1 - train_ratio)
    val_idx, test_known_idx = train_test_split(
        rest_idx, test_size=1 - val_size, random_state=seed,
        stratify=new_labels[rest_idx]
    )
    test_idx = np.concatenate([test_known_idx, unknown_indices])

    # 创建掩码
    num_nodes = data.y.size(0)
    data.train_mask = torch.zeros(num_nodes, dtype=torch.bool)
    data.val_mask = torch.zeros(num_nodes, dtype=torch.bool)
    data.test_mask = torch.zeros(num_nodes, dtype=torch.bool)
    data.train_mask[train_idx] = True
    data.val_mask[val_idx] = True
    data.test_mask[test_idx] = True

    # 创建已知/未知掩码
    data.known_in_unseen_mask = torch.zeros(num_nodes, dtype=torch.bool)
    data.unknown_in_unseen_mask = torch.zeros(num_nodes, dtype=torch.bool)
    data.known_in_unseen_mask[test_known_idx] = True
    data.unknown_in_unseen_mask[unknown_indices] = True

    if save_path:
        split_info = {
            'label_map': label_map,
            'idx_train': train_idx,
            'idx_val': val_idx,
            'idx_test': test_idx,
            'idx_known_unseen': test_known_idx,
            'idx_unknown_unseen': unknown_indices,
        }
        with open(save_path, 'wb') as f:
            pickle.dump(split_info, f)

    # print(f"Train nodes: {(train_idx)}, Val nodes: {(val_idx)}, Test nodes: {(test_idx)}")
    # input("Press Enter to continue...")
    return data, num_known, num_classes-num_known

data, num_known_classes, num_unknown_classes = make_openset_split_auto(
        data, 
        known_class_ratio=0.7,
        train_ratio=0.1,
        val_ratio=0.1,
        seed=seed,
        save_path=None
    )

num_classes = num_known_classes + 1
args['known_class'] = num_known_classes  # 未知类标签设为num_classes（C+1）


# 划分训练集索引
train_indices = np.where(data.train_mask.numpy())[0]
pre_indices, later_indices = train_test_split(train_indices, test_size=0.5, random_state=42)

# EGonc模型（基于GCN）
class EGonc(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels):
        super().__init__()
        self.conv1 = GCNConv(in_channels, hidden_channels)
        self.conv2 = GCNConv(hidden_channels, hidden_channels)
        self.conv3 = torch.nn.Linear(hidden_channels, out_channels)  # 输出层为C+1类

    def forward(self, x, edge_index):
        # 前两层用于生成嵌入（中间层用于混合）
        x1 = F.relu(self.conv1(x, edge_index))
        x2 = F.relu(self.conv2(x1, edge_index))
        x3 = self.conv3(x2)  # 最终logits
        return x3, x2  # 返回logits和中间层嵌入

# 生成替代未知节点
def generate_substitutes(model, data, pre_indices, args):
    x, edge_index = data.x, data.edge_index
    _, h = model(x, edge_index)  # 获取中间层嵌入
    adj = torch.zeros((x.shape[0], x.shape[0]), device=x.device)
    adj[edge_index[0], edge_index[1]] = 1  # 邻接矩阵

    # 1. 类间替代节点（inter-class substitutes）
    inter_substitutes = []
    inter_edges = []
    for i in pre_indices:
        for j in pre_indices:
            if i != j and adj[i, j] == 1 and data.y[i] != data.y[j]:
                # Beta分布采样混合系数
                alpha = Beta(args['alpha'], args['alpha']).sample().item()
                # 生成混合嵌入
                mix_h = alpha * h[i] + (1 - alpha) * h[j]
                inter_substitutes.append(mix_h)
                # 添加与父节点的边
                new_node_idx = x.shape[0] + len(inter_substitutes) - 1
                inter_edges.append([new_node_idx, i])
                inter_edges.append([new_node_idx, j])
                inter_edges.append([i, new_node_idx])
                inter_edges.append([j, new_node_idx])

    # 2. 外部替代节点（external substitutes）
    external_substitutes = []
    external_edges = []
    # 计算类中心
    class_centers = {}
    for c in range(num_classes):
        # Move tensor to CPU before comparison
        class_mask = (data.y[pre_indices] == c)
        class_nodes = pre_indices[class_mask.cpu().numpy()]
        class_centers[c] = h[class_nodes].mean(dim=0) if len(class_nodes) > 0 else torch.zeros_like(h[0])
    
    # 边缘节点：叶节点（度为1）和低置信度节点
    degrees = adj.sum(dim=1).cpu().numpy()
    leaf_nodes = [i for i in pre_indices if degrees[i] == 1]
    
    # 低置信度节点（需先计算一次模型输出）
    logits, _ = model(x, edge_index)
    probs = F.softmax(logits, dim=1)
    max_probs, _ = probs.max(dim=1)
    # 使用detach()将tensor从计算图中分离
    max_probs_np = max_probs.detach().cpu().numpy()
    low_conf_nodes = pre_indices[np.argsort(max_probs_np[pre_indices])[:int(0.1*len(pre_indices))]]
    
    # 使用list的extend方法合并两个列表
    peripheral_nodes = []
    peripheral_nodes.extend(leaf_nodes)
    peripheral_nodes.extend(low_conf_nodes)
    peripheral_nodes = list(set(peripheral_nodes))  # 去重


    for i in peripheral_nodes:
        c = data.y[i].item()
        # 混合边缘节点与反向类中心
        mix_h = args['beta'] * h[i] + args['gamma'] * (-class_centers[c])
        external_substitutes.append(mix_h)
        # 添加与父节点的边
        new_node_idx = x.shape[0] + len(inter_substitutes) + len(external_substitutes) - 1
        external_edges.append([new_node_idx, i])
        external_edges.append([i, new_node_idx])

    # 整合新节点和边
    if inter_substitutes or external_substitutes:
        new_h = torch.stack(inter_substitutes + external_substitutes)
        # 创建与原始特征相同维度的零向量作为替代节点的特征
        new_features = torch.zeros((len(inter_substitutes) + len(external_substitutes), x.shape[1]), 
                                 device=x.device, dtype=x.dtype)
        # 合并特征
        new_x = torch.cat([x, new_features], dim=0)
        new_edge_index = torch.cat([
            edge_index,
            torch.tensor(inter_edges + external_edges, dtype=torch.long, device=edge_index.device).t()
        ], dim=1)
        # 新节点标签（未知类）
        new_labels = torch.cat([
            data.y,
            torch.full((len(inter_substitutes) + len(external_substitutes),), 
                      args['known_class'], device=data.y.device)
        ])
        return new_x, new_edge_index, new_labels, len(inter_substitutes) + len(external_substitutes)
    return x, edge_index, data.y, 0

# 能量传播
def energy_propagation(energy, edge_index, zeta=0.5):
    n = energy.shape[0]
    # 构建归一化邻接矩阵
    adj = torch.zeros((n, n), device=energy.device)
    adj[edge_index[0], edge_index[1]] = 1
    deg = adj.sum(dim=1).clamp(min=1).sqrt()
    deg_inv = 1.0 / deg
    adj_norm = deg_inv.view(-1, 1) * adj * deg_inv.view(1, -1)  # 对称归一化
    # 能量传播
    energy_propagated = zeta * energy + (1 - zeta) * adj_norm @ energy
    return energy_propagated

# 互补熵损失
def complement_entropy_loss(logits, labels, known_class):
    loss = 0.0
    # 已知类：最小化被误分类到其他已知类的概率
    for c in range(known_class):
        mask = (labels == c)
        if mask.sum() == 0:
            continue
        # 排除真实标签的logits
        logits_masked = logits[mask]
        logits_masked = logits_masked[:, [i for i in range(known_class) if i != c]]
        probs_masked = F.softmax(logits_masked, dim=1)
        loss += -torch.mean(probs_masked * torch.log(probs_masked + 1e-8))
    
    # 替代样本：最小化在已知类上的平均熵
    mask_unknown = (labels == known_class)
    if mask_unknown.sum() > 0:
        logits_unknown = logits[mask_unknown, :known_class]
        probs_unknown = F.softmax(logits_unknown, dim=1)
        loss += -torch.mean(torch.sum(probs_unknown * torch.log(probs_unknown + 1e-8), dim=1))
    return loss

# 能量正则化损失
def energy_regularization_loss(energy, labels, known_class, t_in, t_out, k1, k2):
    mask_ind = (labels < known_class)
    mask_ood = (labels == known_class)
    if mask_ind.sum() == 0 or mask_ood.sum() == 0:
        return 0.0
    # 已知类能量误差
    energy_ind = energy[mask_ind]
    error_ind = F.leaky_relu(energy_ind - t_in)
    # 未知类能量误差
    energy_ood = energy[mask_ood]
    error_ood = F.leaky_relu(t_out - energy_ood)
    # 线性+二次损失
    loss = k1 * (torch.sum(error_ind) + torch.sum(error_ood)) + \
           k2 * (torch.sum(error_ind **2) + torch.sum(error_ood** 2))
    return loss / (mask_ind.sum() + mask_ood.sum())

# 模型初始化与优化器
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

model = EGonc(dataset.num_features, 512, num_classes + 1).to(device)  # 输出层为C+1
data = data.to(device)
optimizer = torch.optim.SGD(model.parameters(), lr=args['lr'], momentum=0.9, weight_decay=5e-4)

# 训练循环
for epoch in range(args['epochs']):
    model.train()
    optimizer.zero_grad()
    
    # 生成替代未知节点
    new_x, new_edge_index, new_labels, num_substitutes = generate_substitutes(
        model, data, pre_indices, args
    )
    
    # 模型输出
    logits, _ = model(new_x, new_edge_index)
    # 计算能量分数
    energy = -torch.logsumexp(logits, dim=1)
    # 能量传播
    energy_propagated = energy_propagation(energy, new_edge_index)
    
    # 1. 交叉熵损失 (l1)
    mask_train = torch.cat([
        data.train_mask,
        torch.ones(num_substitutes, dtype=torch.bool, device=device)  # 替代样本全部用于训练
    ])
    l1 = F.cross_entropy(logits[mask_train], new_labels[mask_train])
    
    # 2. 互补熵损失 (l2)
    l2 = complement_entropy_loss(logits[mask_train], new_labels[mask_train], num_classes)
    
    # 3. 能量正则化损失 (l3)
    l3 = energy_regularization_loss(
        energy_propagated[mask_train], new_labels[mask_train],
        num_classes, args['t_in'], args['t_out'], args['k1'], args['k2']
    )
    
    # 总损失
    total_loss = l1 + args['lambda2'] * l2 + args['lambda3'] * l3
    total_loss.backward()
    optimizer.step()
    
    # 验证
    if (epoch + 1) % 10 == 0:
        model.eval()
        with torch.no_grad():
            logits_val, _ = model(data.x, data.edge_index)
            pred = logits_val.argmax(dim=1)
            acc = (pred[data.test_mask] == data.y[data.test_mask]).float().mean()
            acc_known_in_unseen = (pred[data.known_in_unseen_mask] == data.y[data.known_in_unseen_mask]).float().mean()

            print(f'Epoch {epoch+1}, Loss: {total_loss.item():.4f}, Test Acc: {acc.item():.4f}, Known in Unseen Acc: {acc_known_in_unseen.item():.4f}')