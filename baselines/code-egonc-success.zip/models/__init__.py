from .GCN_model2_bn import *
from .GCN_OGB import *
