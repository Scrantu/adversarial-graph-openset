from .GCN_model2 import *
