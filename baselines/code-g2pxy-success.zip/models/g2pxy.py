import torch
import torch.nn as nn
import torch.optim as optim
from copy import deepcopy
import numpy as np
from sklearn.model_selection import train_test_split
from .GCN_model2 import GCN_model2

class G2Pxy(nn.Module):
    """G2Pxy: 图神经网络的开集分类模型
    
    主要功能:
    1. 使用GCN进行节点特征提取
    2. 生成新的样本点来增强决策边界
    3. 使用额外的分类头来检测未知类
    """
    
    def __init__(self, num_features, num_known_classes, hidden_dim=512, embed_dim=128, 
                 lr=0.1, weight_decay=5e-4, device='cuda'):
        super().__init__()
        self.device = device
        self.num_known_classes = num_known_classes
        
        # 初始化GCN模型
        self.model = GCN_model2(
            num_features,  # 输入特征维度
            hidden_dim,    # 隐层维度
            embed_dim,     # 嵌入维度
            num_known_classes + 1  # 已知类别数 + 1个未知类
        ).to(device)
        
        # 优化器
        self.optimizer = optim.SGD(
            self.model.parameters(),
            lr=lr,
            momentum=0.9,
            weight_decay=weight_decay
        )
        self.optimizer = torch.optim.Adam(
            list(self.model.parameters()),
            lr=lr, weight_decay=weight_decay
        )

        self.criterion = nn.CrossEntropyLoss()
        
    def forward(self, x, edge_index):
        """前向传播"""
        return self.model(x, edge_index)

    def _mix_embeddings(self, embeddings, edge_index, labels, indices, beta):
        """生成混合嵌入
        通过对不同类别的节点对进行插值来生成新的嵌入
        """
        mixed_embeddings = []
        parent_nodes = []
        
        # 找到所有边的源节点和目标节点
        src, dst = edge_index[:, indices]
        
        # 遍历每条边
        for s, d in zip(src, dst):
            # 如果连接的是不同类的节点
            if labels[s] != labels[d]:
                # 生成混合嵌入
                mix_embed = beta * embeddings[s] + (1 - beta) * embeddings[d]
                mixed_embeddings.append(mix_embed)
                parent_nodes.append((s.item(), d.item()))
                
        if mixed_embeddings:
            return torch.stack(mixed_embeddings), parent_nodes
        return None, []

    def train_step(self, x, edge_index, labels, train_mask):
        """训练一个批次
        
        参数:
            x: 节点特征矩阵
            edge_index: 边的连接关系
            labels: 节点标签
            train_mask: 训练集掩码
        """
        self.train()
        self.optimizer.zero_grad()
        
        # 获取训练节点索引
        train_idx = torch.where(train_mask)[0]
        
        # 随机划分训练节点为两部分
        pre_idx, later_idx = train_test_split(train_idx.cpu(), test_size=0.5)
        pre_idx = torch.tensor(pre_idx).to(self.device)
        later_idx = torch.tensor(later_idx).to(self.device)
        
        # 第一阶段特征提取
        embeddings = self.model.get_embeddings(x, edge_index)
        
        # 生成混合嵌入
        beta = torch.distributions.beta.Beta(1, 1).sample([]).item()
        mixed_embed, parent_nodes = self._mix_embeddings(
            embeddings, edge_index, labels, pre_idx, beta
        )
        
        if mixed_embed is not None:
            # 将原始嵌入和混合嵌入拼接
            all_embeddings = torch.cat([embeddings, mixed_embed])
            
            # 构建新的edge_index，连接混合节点与其父节点
            new_edges = []
            num_orig_nodes = embeddings.shape[0]
            for i, (p1, p2) in enumerate(parent_nodes):
                new_node_idx = num_orig_nodes + i
                new_edges.extend([
                    [new_node_idx, p1],
                    [new_node_idx, p2],
                    [p1, new_node_idx],
                    [p2, new_node_idx]
                ])
            
            new_edge_index = torch.cat([
                edge_index,
                torch.tensor(new_edges).t().to(self.device)
            ], dim=1)
            
            # 计算最终输出
            outputs = self.model.forward_with_embeddings(all_embeddings, new_edge_index)
            
            # 计算损失
            # 所有训练节点的分类损失
            loss_cls = self.criterion(outputs[train_idx], labels[train_idx])
            
            # 混合节点的损失 - 预测为未知类
            unknown_targets = torch.ones(len(parent_nodes)).long().to(self.device) * self.num_known_classes
            mix_indices = torch.arange(num_orig_nodes, len(all_embeddings)).to(self.device)
            loss_mix = self.criterion(outputs[mix_indices], unknown_targets)
            
            # 总损失 = 分类损失 + 混合节点损失
            loss = loss_cls
            
            loss.backward()
            self.optimizer.step()
            
            return loss.item()
        
        return 0.0

    @torch.no_grad()
    def predict(self, x, edge_index):
        """模型预测"""
        self.eval()
        logits = self.forward(x, edge_index)
        return logits

    @torch.no_grad()
    def get_energy_score(self, logits, temperature=1.0):
        """计算能量分数
        较高的能量分数表示样本更可能属于已知类
        只考虑已知类的logits来计算能量分数
        """
        # 只取已知类的logits（去掉最后一维，即未知类的logit）
        known_logits = logits[:, :self.num_known_classes]
        # 计算能量分数
        return temperature * torch.logsumexp(known_logits / temperature, dim=1)

    def save(self, path):
        """保存模型"""
        torch.save({
            'model_state_dict': self.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
        }, path)

    def load(self, path):
        """加载模型"""
        checkpoint = torch.load(path)
        self.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])




